import urllib2
import time
import csv
import sys
import os
import re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from _io import open
from _ast import Str
from locale import str
from test.test_iterlen import len
from pip._vendor.distlib.compat import raw_input

court_number_regex = "[0-9]{2}-[0-9]{5}-[a-zA-Z0-9]{5}"
creditor_number_regex = "([0-9]+)"
cr_regex = "(cr)"
case_type_string = "Case type:"
chapter_string = "Chapter:"
asset_string = "Asset:"
vol_string = "Vol:"
judge_string = "Judge:"
date_filed_string = "Date filed:"
date_of_last_filing_string = "Date of last filing:"

inputPath = os.getcwd() + "/output/"
print "Enter output folder name"
o = raw_input()
outputPath = os.getcwd() + "/" + o + "/"
if not os.path.exists(outputPath):
    os.mkdir(outputPath)
print outputPath
print "Enter QR_Code"
qr_code = raw_input()

print "Please wait..."

# Gets output Folder
driver = webdriver.Firefox()
main_window = driver.current_window_handle
counter = 0

for file in os.listdir(inputPath):
    if file.endswith(".html"):
        driver.find_element_by_css_selector('body').send_keys(Keys.CONTROL + 't')
        driver.get("file:///" + inputPath + file)
        data = open(outputPath + "source" + str(counter) + qr_code + ".txt", 'w')

        # Reads main data
        main_data = driver.find_element_by_css_selector('center').text
        case_number = re.findall(court_number_regex, main_data)[0]
        name = (main_data.split(case_number))[1].split(case_type_string)[0].strip()
        case_type = (main_data.split(case_type_string))[1].split(chapter_string)[0].strip()
        chapter = (main_data.split(chapter_string))[1].split(asset_string)[0].strip()
        asset = (main_data.split(asset_string))[1].split(vol_string)[0].strip()
        vol = (main_data.split(vol_string))[1].split(judge_string)[0].strip()
        judge = (main_data.split(judge_string))[1].split(date_filed_string)[0].strip()
        date_filed = (main_data.split(date_filed_string))[1].split(date_of_last_filing_string)[0].strip()
        date_of_last_filing = (main_data.split(date_of_last_filing_string))[1].split("Creditors")[0].strip()
        
        #print "Case Number: " + case_number
        #print "Name: " + name
        #print "Case type: " + case_type
        #print "Chapter: " + chapter
        #print "Asset: " + asset
        #print "Vol: " + vol
        #print "Judge: " + judge
        #print "Date Filed: " + date_filed
        #print "Date of last filing: " + date_of_last_filing
        
        # Reads creditor data
        tables = driver.find_elements_by_css_selector("table")
        table = tables[0]
        rows = table.find_elements_by_xpath(".//tr")
        cells = rows[0].find_elements_by_xpath(".//td")
        cell = cells[0]
        #print cell.text
        #for row in rows:
            #cells = row.find_elements_by_tag_name("td")
            #if (len(cells) > 0):
                #cell = cells[0]
                #print cell.text
        
        # Generates letter
        output = cell.text + "\n\nNotice of Recent Bankruptcy Filing\n\nDetails:\n\n" + case_number + " " + name + "\nCase type: " + case_type + " Chapter: " + chapter + " Asset: " + asset + " Vol: " + vol + " Judge: " + judge + "\nDate filed: " + date_filed + " Date of last filing: " + date_of_last_filing
        
        data.write(output)
        data.close()
        counter += 1
 
print "Finished letter generation"
driver.close()
